
class Point2:
    def helper(self, msg):
        print(msg + " 2")

    def dummy(self):
        return None


class Monkey:
    def banana(self):
        print("eat")
