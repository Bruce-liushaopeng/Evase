class Point2:
    def print(self, msg):
        print(msg + " 4")