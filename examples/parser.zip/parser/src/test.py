from test4 import Point
from parse import cool


class Point2:
    class test1:
        def here(self):
            print(1)

    def do(self, message):
        from src.test123.test2 import Point
        a = t()
        p = Point()
        p.do(1)
        print(1)

    def doit(self, message):
        from src.test123.test2 import Point
        cool()
        print(1)

    class here:
        def hereprint(self):
            print(1)
