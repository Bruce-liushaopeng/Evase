from test4 import *

class Point:

    def do(self, message):
        print("test 2" )
def fun():
    print("here")
