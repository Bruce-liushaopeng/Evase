def cool():
    print(1)

def cool2():
    print(1)