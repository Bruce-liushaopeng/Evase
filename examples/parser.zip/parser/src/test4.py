
class Point:
    class here:
        def one(self):
            print(1)

    def do(self, message):
        print("Point test 4")

class Point3:
    def do(self, message):
        print("Point3 test 4")