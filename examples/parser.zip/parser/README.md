# EVASE-Parsing-Prototype
This repository contains the parsing prototypes for the EVASE project.
